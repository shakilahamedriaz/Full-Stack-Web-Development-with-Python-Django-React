# packet
# immutable data structure
# no edit, no delete, no addtion

a = (1,2,3,4)
# a[0] = 100
print(a, type(a))

# a = ("Rahim", 5, 20)
# a = list(a)
# a[1] = 6
# a[2] = 21
# print(a)
# a = tuple(a)
# print(a)

a = 1,2,3
print(a, type(a), a[2])