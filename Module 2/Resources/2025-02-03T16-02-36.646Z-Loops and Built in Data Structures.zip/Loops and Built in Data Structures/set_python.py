# etao ekta bajarer packet
# duplicate nite parben na
# no indexing, Unordered

a = {1,2,3,3,3,3,4} 
# Intersection, connection point, common point
b = {10,12,13,4}
b.add(100)
print(b)
print(a.intersection(b))

# Union, valo manush, mile mishe sobar sathe thakte chay

print(a.union(b))