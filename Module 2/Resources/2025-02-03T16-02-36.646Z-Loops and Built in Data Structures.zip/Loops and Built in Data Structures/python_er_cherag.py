# range() 

# machine --> input - Orange
        #   ---> output - Juice (glass, batite)

a = list(range(10)) # 10 ta value, 0 -> (n-1)
print(a)

a = tuple(range(1,10)) # 10-1 = 9 ta value amar dibe
print(a)

a = tuple(range(1, 10, 2))
print(a)